<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=100%, initial-scale=1.0">
    <title>Tarecos do ISMIAU</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
<?php
include "header.php"
?>

<h1 style="text-align:center">QUER DOAR ?</h1><br>

<p><h2>Caso não tenha possibilidades de adotar um dos nossos gatos, mas queira na mesma ajudar a associação, pode fazer um donativo através do Paypal. 
Esse dinheiro será usado para comprar bens, rações e medicação para os nossos animais.</h2></p>


<p><h2>Se não quiser ajudar mas prefere não fazer donativos em forma de dinheiro pode também dirigir-se à nossa associação e doar, por exemplo:</h2></p>
<ul>
  <li><h4>AREIA</h4></li>
  <li><h4>RAÇÃO SECA OU HÚMIDA</h4></li>
  <li><h4>ACESSÓRIOS E BRINQUEDOS</h4></li>
  <li><h4>CAMAS</h4></li>
  <li><h4>ARRANHADORES</h4></li>
  <li><h4>BISCOITOS/STICKS</h4></li>
  <li><h4>MALAS TRANSPORTADORAS</h4></li>
</ul>
<br>

<a href="https://www.paypal.com/myaccount/summary">  
<img class ="center" src="images/paypal.png"><br></a>




<?php
include "footer.php"
?>
</body>


</html>
