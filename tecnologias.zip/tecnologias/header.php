<header  class="site-header">
  <div class= "cor" class="site-identity">
    <h1><a href="index.php">Tarecos do ISMIAU</a></h1>
  </div>  
  <nav class="site-navigation">
    <ul class="nav">
      <li><a href="index.php">Página Inicial</a></li> 
      <li><a href="tarecos.php">Tarecos</a></li>
      <li><a href="sobre.php">Sobre Nós</a></li> 
      <li><a href="doacao.php">Doações</a></li> 
    </ul>
  </nav>
</header>