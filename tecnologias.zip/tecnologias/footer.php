<footer>
  <a href="tel:+351229866000"><h4>+351 229 866 000</h4></a><p>
  <a href="https://goo.gl/maps/U1J9WyKtwxC7tcWBA"><h4>Av. Carlos de Oliveira Campos, 4475-690 Maia</h4></a>
  <a href="mailto:tarecosismiau@gmail.com"><h4>tarecosismiau@gmail.com</h4></a></p>
  <p><h4>Copyright Tarecos ISMIAU</h4>
</footer>

